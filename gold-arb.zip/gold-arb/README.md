# Gold Arb — XAUUSD monitor + paper trader (Android)

Runs entirely on the phone, no computer needed:
- Spot XAU/USD from Deriv (live Mon–Fri; paused at weekends)
- PAXG and XAUT gold tokens from Binance, OKX and MEXC (24/7)
- Premium of each token vs spot gold
- Best same-token gap between exchanges after fees, with paper trades and P&L

## Get the APK (no Android Studio needed)
1. Create a free GitHub account → New repository (private is fine).
2. Upload everything in this folder, including the hidden `.github` folder
   (on desktop: drag the folder into "uploading an existing file").
3. Open the repo's **Actions** tab → "Build APK" runs automatically (~5 min).
4. Open the finished run → download **gold-arb-apk** → unzip → `app-debug.apk`.
5. Copy to your Android phone, open it, allow "Install unknown apps".

## Or build locally
Node 20+, Java 21 and Android Studio installed:
```bash
npm install
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```
APK: `android/app/build/outputs/apk/debug/app-debug.apk`

## Change the app
Everything is in `www/index.html`. Edit, push to GitHub, and a new APK builds.

## What the numbers mean
- **Premium**: token price vs spot gold. Tokens often sit at a small premium or
  discount for structural reasons, so this alone is not free money.
- **Best gap**: buy PAXG (or XAUT) on the cheaper exchange, sell the same token on
  the dearer one. Real arbitrage, but only if you already hold USDT on one side and
  the token on the other; moving funds between exchanges takes too long.
- Paper trades assume fills at the displayed price. Real fills will be worse.
